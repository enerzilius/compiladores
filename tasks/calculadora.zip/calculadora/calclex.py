# ------------------------------------------------------------
# calclex.py
#
# tokenizer for a simple expression evaluator for
# numbers and +,-,*,/
# ------------------------------------------------------------
from ply import lex

# List of token names.   This is always required
tokens = (
    # "ID",
    "AND",
    "OR",
    "NOT",
    "NUMBER",
    "PLUS",
    "MINUS",
    "TIMES",
    "DIVIDE",
    "LPAREN",
    "RPAREN",
)

# reconhecimento de identificadores

char = r"([a-zA-ZáÁãÃàÀéÉíÍóÓõÕ])"
digit = r"([0-9])"
id = r"(" + char + r"(" + digit + r"+|_|" + char + r")*)"

# Regular expression rules for simple tokens
t_AND = r"&&"
t_OR = r"\|\|"
t_NOT = r"!"
t_PLUS = r"\+"
t_MINUS = r"-"
t_TIMES = r"\*"
t_DIVIDE = r"/"
t_LPAREN = r"\("
t_RPAREN = r"\)"


# def t_ID(t):
#    t.type = "ID"
#    return t
#
#
# t_ID.__doc__ = id


# A regular expression rule with some action code
def t_NUMBER(t):
    r"\d+"
    t.value = int(t.value)
    return t


# Define a rule so we can track line numbers
def t_newline(t):
    r"\n+"
    t.lexer.lineno += len(t.value)


# A string containing ignored characters (spaces and tabs)
t_ignore = " \t"


# Error handling rule
def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)


# Build the lexer
lexer = lex.lex()
